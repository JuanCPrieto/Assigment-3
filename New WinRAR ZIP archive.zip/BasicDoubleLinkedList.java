import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * A basic double-linked list implementation with generic elements.
 * @param <T> The type of elements stored in the list.
 */
public class BasicDoubleLinkedList<T> implements Iterable<T> {

    /**
     * Inner class representing a node in the double-linked list.
     */
    protected class Node {
        T data;
        Node prev;
        Node next;

        Node(T data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }

    /**
     * Inner class implementing the ListIterator interface for iterating through the list.
     */
    protected class DoubleLinkedListIterator implements ListIterator<T> {
        private Node current = null;
        private Node lastReturned = null;
        private int index = 0;

        public boolean hasNext() {
            return index < size;
        }

        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            if (current == null) {
                current = head;
            } else {
                current = current.next;
            }
            lastReturned = current;
            index++;
            return current.data;
        }

        public boolean hasPrevious() {
            return index > 0;
        }

        public T previous() {
            if (!hasPrevious()) {
                throw new NoSuchElementException();
            }
            if (current == null) {
                current = tail;
            } else {
                current = current.prev;
            }
            lastReturned = current;
            index--;
            return current.data;
        }

        // Implement these methods to support the ListIterator interface.
        @Override
        public int nextIndex() {
            return index;
        }

        @Override
        public int previousIndex() {
            return index - 1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Remove operation is not supported.");
        }

        @Override
        public void set(T e) {
            if (lastReturned == null) {
                throw new IllegalStateException("No element has been returned yet.");
            }
            lastReturned.data = e;
        }

        @Override
        public void add(T e) {
            throw new UnsupportedOperationException("Add operation is not supported.");
        }
    }

    Node head;
    private Node tail;
    protected int size;

    /**
     * Constructs an empty double-linked list.
     */
    public BasicDoubleLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    /**
     * Adds an element to the end of the list.
     * @param data The data to be added to the end of the list.
     */
    public void addToEnd(T data) {
        Node newNode = new Node(data);
        if (tail == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
    }

    /**
     * Adds an element to the front of the list.
     * @param data The data to be added to the front of the list.
     */
    public void addToFront(T data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        size++;
    }

    /**
     * Retrieves the first element in the list.
     * @return The first element in the list.
     * @throws NoSuchElementException if the list is empty.
     */
    public T getFirst() {
        if (head == null) {
            throw new NoSuchElementException();
        }
        return head.data;
    }

    /**
     * Retrieves the last element in the list.
     * @return The last element in the list.
     * @throws NoSuchElementException if the list is empty.
     */
    public T getLast() {
        if (tail == null) {
            throw new NoSuchElementException();
        }
        return tail.data;
    }

    /**
     * Gets the size of the list.
     * @return The number of elements in the list.
     */
    public int getSize() {
        return size;
    }

    /**
     * Returns an iterator to traverse the list.
     * @return An iterator for the list.
     */
    public ListIterator<T> iterator() {
        return new DoubleLinkedListIterator();
    }

    /**
     * Removes a node from the list based on the target data and a comparator.
     * @param targetData The data to be removed from the list.
     * @param comparator The comparator used to compare elements.
     * @return The removed node, or null if not found.
     */
    public Node remove(T targetData, Comparator<T> comparator) {
        Node current = head;
        while (current != null) {
            if (comparator.compare(current.data, targetData) == 0) {
                Node prevNode = current.prev;
                Node nextNode = current.next;
                if (prevNode != null) {
                    prevNode.next = nextNode;
                } else {
                    head = nextNode;
                }
                if (nextNode != null) {
                    nextNode.prev = prevNode;
                } else {
                    tail = prevNode;
                }
                size--;
                return current;
            }
            current = current.next;
        }
        return null;
    }

    /**
     * Retrieves and removes the first element in the list.
     * @return The first element in the list.
     * @throws NoSuchElementException if the list is empty.
     */
    public T retrieveFirstElement() {
        if (head == null) {
            throw new NoSuchElementException();
        }
        T data = head.data;
        head = head.next;
        if (head == null) {
            tail = null;
        } else {
            head.prev = null;
        }
        size--;
        return data;
    }

    /**
     * Retrieves and removes the last element in the list.
     * @return The last element in the list.
     * @throws NoSuchElementException if the list is empty.
     */
    public T retrieveLastElement() {
        if (tail == null) {
            throw new NoSuchElementException();
        }
        T data = tail.data;
        tail = tail.prev;
        if (tail == null) {
            head = null;
        } else {
            tail.next = null;
        }
        size--;
        return data;
    }

    /**
     * Converts the double-linked list to an ArrayList.
     * @return An ArrayList containing the elements from the list in order.
     */
    public ArrayList<T> toArrayList() {
        ArrayList<T> list = new ArrayList<>();
        Node current = head;
        while (current != null) {
            list.add(current.data);
            current = current.next;
        }
        return list;
    }
}

