import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.ListIterator;

import static org.junit.Assert.*;

public class BasicDoubleLinkedListStudentTest {

    private BasicDoubleLinkedList<Integer> list;

    @Before
    public void setUp() {
        list = new BasicDoubleLinkedList<>();
    }

    @Test
    public void testAddToEnd() {
        list.addToEnd(1);
        list.addToEnd(2);
        list.addToEnd(3);

        ArrayList<Integer> arrayList = list.toArrayList();

        assertEquals(3, list.getSize());
        assertEquals(Integer.valueOf(1), arrayList.get(0));
        assertEquals(Integer.valueOf(2), arrayList.get(1));
        assertEquals(Integer.valueOf(3), arrayList.get(2));
    }

    @Test
    public void testAddToFront() {
        list.addToFront(1);
        list.addToFront(2);
        list.addToFront(3);

        ArrayList<Integer> arrayList = list.toArrayList();

        assertEquals(3, list.getSize());
        assertEquals(Integer.valueOf(3), arrayList.get(0));
        assertEquals(Integer.valueOf(2), arrayList.get(1));
        assertEquals(Integer.valueOf(1), arrayList.get(2));
    }

    @Test
    public void testGetFirst() {
        list.addToEnd(1);
        list.addToEnd(2);

        assertEquals(Integer.valueOf(1), list.getFirst());
    }

    @Test(expected = NoSuchElementException.class)
    public void testGetFirstEmptyList() {
        list.getFirst();
    }

    @Test
    public void testGetLast() {
        list.addToEnd(1);
        list.addToEnd(2);

        assertEquals(Integer.valueOf(2), list.getLast());
    }

    @Test(expected = NoSuchElementException.class)
    public void testGetLastEmptyList() {
        list.getLast();
    }

    @Test
    public void testRemove() {
        list.addToEnd(1);
        list.addToEnd(2);
        list.addToEnd(3);

        Comparator<Integer> comparator = Integer::compareTo;
        BasicDoubleLinkedList.Node removedNode = list.remove(2, comparator);

        ArrayList<Integer> arrayList = list.toArrayList();

        assertEquals(2, list.getSize());
        assertEquals(Integer.valueOf(1), arrayList.get(0));
        assertEquals(Integer.valueOf(3), arrayList.get(1));
        assertEquals(Integer.valueOf(2), removedNode.data);
    }

    @Test
    public void testRemoveNonExistentElement() {
        list.addToEnd(1);
        list.addToEnd(2);

        Comparator<Integer> comparator = Integer::compareTo;
        BasicDoubleLinkedList.Node removedNode = list.remove(3, comparator);

        assertNull(removedNode);
        assertEquals(2, list.getSize());
    }

    @Test
    public void testRetrieveFirstElement() {
        list.addToEnd(1);
        list.addToEnd(2);

        Integer retrieved = list.retrieveFirstElement();

        ArrayList<Integer> arrayList = list.toArrayList();

        assertEquals(Integer.valueOf(1), retrieved);
        assertEquals(1, list.getSize());
        assertEquals(Integer.valueOf(2), arrayList.get(0));
    }

    @Test(expected = NoSuchElementException.class)
    public void testRetrieveFirstElementEmptyList() {
        list.retrieveFirstElement();
    }

    @Test
    public void testRetrieveLastElement() {
        list.addToEnd(1);
        list.addToEnd(2);

        Integer retrieved = list.retrieveLastElement();

        ArrayList<Integer> arrayList = list.toArrayList();

        assertEquals(Integer.valueOf(2), retrieved);
        assertEquals(1, list.getSize());
        assertEquals(Integer.valueOf(1), arrayList.get(0));
    }

    @Test(expected = NoSuchElementException.class)
    public void testRetrieveLastElementEmptyList() {
        list.retrieveLastElement();
    }

    @Test
    public void testIterator() {
        list.addToEnd(1);
        list.addToEnd(2);
        list.addToEnd(3);

        ListIterator<Integer> iterator = list.iterator();

        assertEquals(true, iterator.hasNext());
        assertEquals(Integer.valueOf(1), iterator.next());

        assertEquals(true, iterator.hasNext());
        assertEquals(Integer.valueOf(2), iterator.next());

        assertEquals(true, iterator.hasPrevious());
        assertEquals(Integer.valueOf(2), iterator.previous());

        assertEquals(true, iterator.hasPrevious());
        assertEquals(Integer.valueOf(1), iterator.previous());

        assertEquals(false, iterator.hasPrevious());
    }
}
