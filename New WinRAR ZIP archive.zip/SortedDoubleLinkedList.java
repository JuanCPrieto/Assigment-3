
import java.util.Comparator;
import java.util.ListIterator;

/**
 * A generic doubly-linked list that maintains its elements in sorted order
 * based on a provided comparator.
 *
 * @param <T> The data type of elements in the list.
 */
public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {
    private Comparator<T> comparator;

    /**
     * Creates a new instance of the sorted doubly-linked list with the specified comparator.
     *
     * @param comparator The comparator used to determine the order of elements in the list.
     */
    public SortedDoubleLinkedList(Comparator<T> comparator) {
        this.comparator = comparator;
    }

    /**
     * Adds an element to the sorted list in its appropriate position based on the comparator.
     *
     * @param data The data to be added to the list.
     */
    public void add(T data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            addToFront(data);
        } else {
            Node current = head;
            Node previous = null;

            while (current != null && comparator.compare(data, current.data) > 0) {
                previous = current;
                current = current.next;
            }

            if (previous == null) {
                addToFront(data);
            } else if (current == null) {
                addToEnd(data);
            } else {
                previous.next = newNode;
                newNode.prev = previous;
                newNode.next = current;
                current.prev = newNode;
                size++;
            }
        }
    }

    private boolean isEmpty() {
        return size == 0;
    }

    /**
     * Throws an UnsupportedOperationException since adding to the end is not allowed
     * in a sorted list.
     *
     * @param data The data to be added to the end of the list.
     */
    @Override
    public void addToEnd(T data) {
        throw new UnsupportedOperationException("This operation is invalid for a sorted list.");
    }

    /**
     * Throws an UnsupportedOperationException since adding to the front is not allowed
     * in a sorted list.
     *
     * @param data The data to be added to the front of the list.
     */
    @Override
    public void addToFront(T data) {
        throw new UnsupportedOperationException("This operation is invalid for a sorted list.");
    }

    /**
     * Returns an iterator for the sorted list.
     *
     * @return A list iterator.
     */
    @Override
    public ListIterator<T> iterator() {
        return super.iterator();
    }

    /**
     * Removes an element from the list based on the provided comparator.
     *
     * @param data       The data to be removed from the list.
     * @param comparator The comparator used to determine which element to remove.
     * @return The removed node, or null if the element was not found.
     */
    @Override
    public Node remove(T data, Comparator<T> comparator) {
        return super.remove(data, comparator);
    }
}
