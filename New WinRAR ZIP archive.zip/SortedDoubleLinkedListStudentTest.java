import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * JUnit test class for the SortedDoubleLinkedList class.
 */
public class SortedDoubleLinkedListStudentTest {
    private SortedDoubleLinkedList<Integer> sortedList;
    private Comparator<Integer> naturalOrderComparator;

    @Before
    public void setUp() {
        naturalOrderComparator = Comparator.naturalOrder();
        sortedList = new SortedDoubleLinkedList<>(naturalOrderComparator);
    }

    /**
     * Test adding elements to a sorted list and ensuring they are sorted correctly.
     */
    @Test
    public void testAdd() {
        sortedList.add(5);
        sortedList.add(2);
        sortedList.add(7);
        sortedList.add(1);
        sortedList.add(3);

        ListIterator<Integer> iterator = sortedList.iterator();
        assertEquals(1, iterator.next().intValue());
        assertEquals(2, iterator.next().intValue());
        assertEquals(3, iterator.next().intValue());
        assertEquals(5, iterator.next().intValue());
        assertEquals(7, iterator.next().intValue());
    }

    /**
     * Test adding an element to an empty sorted list.
     */
    @Test
    public void testAddEmptyList() {
        sortedList.add(42);
        ListIterator<Integer> iterator = sortedList.iterator();
        assertEquals(42, iterator.next().intValue());
    }

    /**
     * Test adding a single element to a sorted list.
     */
    @Test
    public void testAddSingleElement() {
        sortedList.add(10);
        sortedList.add(5);
        ListIterator<Integer> iterator = sortedList.iterator();
        assertEquals(5, iterator.next().intValue());
        assertEquals(10, iterator.next().intValue());
    }

    /**
     * Test attempting to add an element to the front, which should throw UnsupportedOperationException.
     */
    @Test(expected = UnsupportedOperationException.class)
    public void testAddToFront() {
        sortedList.addToFront(10);
    }

    /**
     * Test attempting to add an element to the end, which should throw UnsupportedOperationException.
     */
    @Test(expected = UnsupportedOperationException.class)
    public void testAddToEnd() {
        sortedList.addToEnd(20);
    }

    /**
     * Test removing an element from a sorted list using a custom comparator.
     */
    @Test
    public void testRemove() {
        sortedList.add(5);
        sortedList.add(10);
        sortedList.add(20);
        sortedList.add(30);

        Comparator<Integer> customComparator = (a, b) -> Integer.compare(b, a);
        sortedList.remove(20, customComparator);

        ListIterator<Integer> iterator = sortedList.iterator();
        assertEquals(30, iterator.next().intValue());
        assertEquals(10, iterator.next().intValue());
        assertEquals(5, iterator.next().intValue());
    }

    /**
     * Test attempting to remove an element not found in the sorted list, which should throw NoSuchElementException.
     */
    @Test(expected = NoSuchElementException.class)
    public void testRemoveNotFound() {
        sortedList.add(5);
        sortedList.add(10);
        sortedList.add(20);
        sortedList.remove(15, naturalOrderComparator);
    }

    /**
     * Test iterating through the sorted list to ensure elements are retrieved in the correct order.
     */
    @Test
    public void testIterator() {
        sortedList.add(5);
        sortedList.add(10);
        sortedList.add(20);

        ListIterator<Integer> iterator = sortedList.iterator();
        assertEquals(5, iterator.next().intValue());
        assertEquals(10, iterator.next().intValue());
        assertEquals(20, iterator.next().intValue());
    }
}
